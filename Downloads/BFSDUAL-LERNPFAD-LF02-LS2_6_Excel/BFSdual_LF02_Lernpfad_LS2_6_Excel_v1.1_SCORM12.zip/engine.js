/* BFS Dual · Lernfeld 2 · eigenständige Lernpfadübung · Lernpfad mit 30 Aufgaben. */
const Engine={
 initial:()=>({v:1401,rows:[],current:null,hint:0,before:[0,0,0,0,0],after:[0,0,0,0,0],screen:'intro',stage:1,checkpointStage:0,storyAnswers:{},storyEval:null,remediation:[],reserveUses:{},stageAttempts:{1:0,2:0}}),
 plan(level){return CORE_PLAN[String(level)]||[]},
 stageRows(s,level){const ids=new Set(this.plan(level));return s.rows.filter(r=>ids.has(r[0]))},
 next(s) {
   if (s.remediation?.length) {
     const coreId = s.remediation[0];
     const variants = BANK.filter(question => question.coreId === coreId);
     const seen = s.reserveUses?.[coreId] || 0;
     return variants[seen % variants.length];
   }
   const coreId = this.plan(s.stage)[this.stageRows(s, s.stage).length];
   return BANK[coreId] || null;
 },
 recordStandard(s, question, mark) {
   const score = Math.round(mark * 1000) / 1000;
   const hints = Number(s.hint || 0);
   if (!Number.isInteger(question.coreId)) {
     s.rows.push([question.id, score, hints]);
     return;
   }
   const coreId = question.coreId;
   const row = s.rows.find(record => record[0] === coreId);
   if (!row || s.remediation[0] !== coreId) throw new Error('Festigungsaufgabe ohne zugehörigen Nachweis');
   if (score > row[1] || (score === row[1] && hints <= row[2])) {
     row.splice(1, row.length - 1, score, hints, question.id);
   }
   s.reserveUses ??= {};
   s.reserveUses[coreId] = (s.reserveUses[coreId] || 0) + 1;
   s.remediation.shift();
 },
 evidence(s,c){return s.rows.filter(r=>BANK[r[0]]&&BANK[r[0]].c===c)},
 evidenceByLevel(s,c,l){return this.evidence(s,c).filter(r=>BANK[r[0]].l===l)},
 stageCompetenceScores(s,l){return [0,1,2,3,4].map(c=>{const rows=this.evidenceByLevel(s,c,l).filter(r=>typeof r[1]==='number');return rows.length?rows.reduce((t,r)=>t+r[1],0)/rows.length:null})},
 stageGate(s,l){const rows=this.stageRows(s,l).filter(r=>typeof r[1]==='number'),overall=this.stageScore(s,l),complete=rows.length===this.plan(l).length,pass=complete&&overall+Number.EPSILON>=.66;return {pass,complete,overall,scores:this.stageCompetenceScores(s,l),thresholds:{overall:.66}}},
 remediationTargets(s,l){const plan=new Set(this.plan(l));return s.rows.filter(r=>plan.has(r[0])&&typeof r[1]==='number'&&r[1]<1).sort((a,b)=>a[1]-b[1]).map(r=>r[0])},
 normalize:x=>String(x).trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ß/g,'ss').replace(/[^a-z0-9]/g,''),
 grade(q,a){if(q.type==='short')return q.answer.some(k=>this.normalize(k)===this.normalize(a))?1:0;if(q.type==='single')return a===q.answer?1:0;if(q.type==='multi'){const correct=q.answer,chosen=a;return Math.max(0,(chosen.filter(x=>correct.includes(x)).length-chosen.filter(x=>!correct.includes(x)).length)/correct.length)}if(q.type==='match'||q.type==='order')return a.reduce((n,v,i)=>n+(v===q.answer[i]?1:0),0)/q.answer.length;return 0},
 ruleScore(rule,answers){const a=rule.steps.map(i=>answers[i]);if(rule.kind==='matrix')return Number(rule.matrix?.[a[0]]?.[a[1]]??0);if(rule.kind==='distance'){const d=Math.abs(a[0]-a[1]);return d===0?Number(rule.same??1):d===1?Number(rule.adjacent??.75):Number(rule.opposite??.4)}return 0},
 storyEvaluation(s){const n=this.plan(3).length,choices=Array.from({length:n},(_,i)=>s.storyAnswers[i]);if(choices.some((x,i)=>!Number.isInteger(x)||x<0||x>=BANK[this.plan(3)[i]].options.length))return null;const answers=choices.map((a,i)=>BANK[this.plan(3)[i]].logicMap?.[a]??a);const rules=TRANSFER_RULES.map(rule=>({...rule,score:this.ruleScore(rule,answers)}));const weighted=rules.reduce((t,r)=>t+r.score*Number(r.weight||1),0),weight=rules.reduce((t,r)=>t+Number(r.weight||1),0)||1,overall=weighted/weight;const perStep=Array.from({length:n},(_,i)=>{const linked=rules.filter(r=>r.steps.includes(i));if(!linked.length)return 1;const w=linked.reduce((t,r)=>t+Number(r.weight||1),0)||1;return linked.reduce((t,r)=>t+r.score*Number(r.weight||1),0)/w});const strong=rules.filter(r=>r.score>=.85).sort((a,b)=>b.score-a.score),tensions=rules.filter(r=>r.score<.85).sort((a,b)=>a.score-b.score),breaks=rules.filter(r=>r.score<.7).sort((a,b)=>a.score-b.score);const label=overall>=.9?'Deine Entscheidungskette ist tragfähig':overall>=.82?'Deine Entscheidungskette ist schlüssig':overall>=.7?'Weitgehend stimmig – ein Punkt bleibt offen':'Deine Entscheidungskette hat noch Brüche';const ways=["Belegweg","Beteiligungsweg","Rahmenweg"];const line=`Start ${ways[answers[0]]} → Präzisierung ${ways[answers[2]]} → Schlussplan ${ways[answers[4]]} → Empfehlung ${ways[answers[5]]}.`;const sameStartFinal=answers[0]===answers[4];const correctionText=sameStartFinal?'Dein roter Faden bleibt bis zum Schluss gut erkennbar.':'Du änderst deinen Weg im Verlauf. Das kann passen, wenn die späteren Entscheidungen den neuen Weg klar weiterführen.';const strengths=strong.slice(0,4).map(r=>r.good),issues=tensions.slice(0,3).map(r=>r.issue),feedforward=tensions.length?tensions[0].next:'Deine Entscheidungen passen gut zusammen. Halte den roten Faden weiter klar.';const decisions=answers.map((a,i)=>{const q=BANK[CORE_PLAN['3'][i]];return {chapter:i+1,title:q.title,choice:q.options[choices[i]],consequence:q.consequences[choices[i]],role:q.logicRoles?.[choices[i]]||''}});return {overall,perStep,label,line,correctionText,strongCount:strong.length,totalRules:rules.length,breakCount:breaks.length,strengths,issues,feedforward,decisions,rules:rules.map(r=>({id:r.id,label:r.label,score:r.score,steps:r.steps}))}},
 applyStoryEvaluation(s){const ev=this.storyEvaluation(s);if(!ev)return null;s.storyEval={overall:ev.overall,perStep:ev.perStep,label:ev.label,strongCount:ev.strongCount,totalRules:ev.totalRules,breakCount:ev.breakCount};for(const r of s.rows){const q=BANK[r[0]];if(q?.type==='story')r[1]=ev.perStep[q.storyIndex]}return ev},
 stageScore(s,l){const rows=this.stageRows(s,l).filter(r=>typeof r[1]==='number');return rows.length?rows.reduce((t,r)=>t+r[1],0)/rows.length:0},
 score(s){const rows=s.rows.filter(r=>typeof r[1]==='number');return rows.length?Math.round(rows.reduce((t,r)=>t+r[1],0)/rows.length*100):0},
 quotaText(c){return 'Testauswahl'},
 completedForCompetence(s,c){return this.evidence(s,c).length},
 result(s,c){const levels=[1,2,3].map(l=>{const r=this.evidenceByLevel(s,c,l).filter(x=>typeof x[1]==='number');return {l,n:r.length,score:r.length?r.reduce((t,x)=>t+x[1],0)/r.length:null}});const last=[...levels].reverse().find(x=>x.n&&x.score!==null);if(!last)return {label:'Kein Testnachweis',text:'Für diese Kompetenz liegt in diesem Stand noch kein Nachweis vor.'};return {label:last.score>=.85?'Sicherer Nachweis':last.score>=.65?'Überwiegend tragfähig':'Weiter festigen',text:`${['','Orientierung','Anwendung','Transfer'][last.l]}: ${Math.round(last.score*100)} % im Testnachweis.`,score:last.score,level:last.l}}
};
if(typeof module!=='undefined')module.exports={Engine};
